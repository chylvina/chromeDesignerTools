/**
 *
 * Author: xiongliang.xl@alibaba-inc.com
 * Since: 13-8-9 下午7:25
 * Description:
 */

'use strict';

var app = angular.module('TagCloudChromeEx', []);